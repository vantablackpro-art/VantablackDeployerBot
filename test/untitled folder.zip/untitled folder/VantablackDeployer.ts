import { anyValue } from "@nomicfoundation/hardhat-chai-matchers/withArgs";
import {
  time,
  loadFixture,
} from "@nomicfoundation/hardhat-toolbox/network-helpers";
import { expect } from "chai";
import hre from "hardhat";
import { ethers, upgrades } from "hardhat";
import { getImplementationAddress } from "@openzeppelin/upgrades-core";
import { HardhatEthersSigner } from "@nomicfoundation/hardhat-ethers/signers";
import { IERC20, PriceOracle } from "../typechain";
import { GameVault, GameVault__factory } from "../typechain";


describe("VantablackDeployer", function () {
  let vantablackDeployer: VantablackDeployer;
  let owner: HardhatEthersSigner, user1: HardhatEthersSigner, user2: HardhatEthersSigner, admin: HardhatEthersSigner;

  beforeEach(async function () {
    [owner, user1, user2, admin] = await ethers.getSigners();

    // Deploy VantablackDeployer implementation (fresh for each test)
    const VantablackDeployerFactory = await ethers.getContractFactory("VantablackDeployer");
    // @ts-ignore
    vantablackDeployer = await upgrades.deployProxy(VantablackDeployerFactory) as GameVault;
    const implAddress = await getImplementationAddress(hre.ethers.provider, await vantablackDeployer.getAddress());
    console.log("GameVault proxy address:", await vantablackDeployer.getAddress());
    console.log("GameVault implementation address:", implAddress);


  });

  describe("Initialization", function () {
    it("Should initialize with correct parameters", async function () {
      expect(1).to.equal(1);
    });
  });

  // describe("Token Support Management", function () {
  //   it("Should add and remove supported tokens", async function () {
  //     expect(await gameVault.isSupportedToken(PLS_TOKEN)).to.be.true;
  //     expect(await gameVault.isSupportedToken(NINE_TOKEN)).to.be.true;

  //     const supportedTokens = await gameVault.getAllSupportedTokens();
  //     expect(supportedTokens).to.include(PLS_TOKEN);
  //     expect(supportedTokens).to.include(NINE_TOKEN);
  //   });

  //   it("Should remove supported token", async function () {
  //     await gameVault.setSupportedToken(PLS_TOKEN, false);

  //     expect(await gameVault.isSupportedToken(PLS_TOKEN)).to.be.false;
  //     const supportedTokens = await gameVault.getAllSupportedTokens();
  //     expect(supportedTokens).to.not.include(PLS_TOKEN);
  //   });

  //   it("Should revert when non-admin tries to set supported token", async function () {
  //     await expect(
  //       gameVault.connect(user1).setSupportedToken(PLS_TOKEN, false)
  //     ).to.be.reverted;
  //   });
  // });

  // describe("Fee Management", function () {
  //   it("Should set fees correctly", async function () {
  //     await gameVault.setFees(100, 200); // 1% deposit, 2% withdraw

  //     expect(await gameVault.depositFeeBP()).to.equal(100);
  //     expect(await gameVault.withdrawFeeBP()).to.equal(200);
  //   });

  //   it("Should revert when fees are too high", async function () {
  //     await expect(gameVault.setFees(1001, 200)).to.be.revertedWithCustomError(gameVault, "FeeTooHigh");
  //     await expect(gameVault.setFees(200, 1001)).to.be.revertedWithCustomError(gameVault, "FeeTooHigh");
  //   });
  // });

  // describe("Oracle Management", function () {
  //   it("Should update oracle", async function () {

  //     const Oracle = await ethers.getContractFactory("PriceOracle");
  //     const newOracle = await Oracle.deploy();
  //     console.log("PriceOracle deployed at:", await priceOracle.getAddress());
  //     await gameVault.updateOracle(await newOracle.getAddress());
  //     expect(await gameVault.oracle()).to.equal(await newOracle.getAddress());
  //   });

  //   it("Should revert when updating to zero address", async function () {
  //     await expect(
  //       gameVault.updateOracle("0x0000000000000000000000000000000000000000")
  //     ).to.be.revertedWithCustomError(gameVault, "ZeroAddress");
  //   });
  // });

  // describe("Access Control", function () {
  //   it("Should grant and revoke admin role", async function () {
  //     await gameVault.addAdmin(await user1.getAddress());
  //     expect(await gameVault.hasRole(await gameVault.ADMIN_ROLE(), await user1.getAddress())).to.be.true;

  //     await gameVault.removeAdmin(await user1.getAddress());
  //     expect(await gameVault.hasRole(await gameVault.ADMIN_ROLE(), await user1.getAddress())).to.be.false;
  //   });

  //   it("Should allow only admin to perform admin functions", async function () {
  //     await expect(
  //       gameVault.connect(user1).setSupportedToken(PLS_TOKEN, false)
  //     ).to.be.reverted;

  //     await expect(
  //       gameVault.connect(user1).setFees(100, 100)
  //     ).to.be.reverted;

  //     await expect(
  //       gameVault.connect(user1).updateOracle(await priceOracle.getAddress())
  //     ).to.be.reverted;
  //   });
  // });

  // describe("View Functions", function () {
  //   // it("Should get contract token balance", async function () {
  //   //   // Send some ETH to the mock WETH contract to simulate balance
  //   //   await owner.sendTransaction({
  //   //     to: await mockWeth.getAddress(),
  //   //     value: ethers.parseEther("50")
  //   //   });

  //   //   const balance = await gameVault.getContractTokenBalance(await mockWeth.getAddress());
  //   //   expect(balance).to.be.gt(0);
  //   // });

  //   it("Should get all supported tokens", async function () {
  //     const supportedTokens = await gameVault.getAllSupportedTokens();
  //     expect(supportedTokens).to.include(PLS_TOKEN);
  //     expect(supportedTokens).to.include(NINE_TOKEN);
  //   });

  //   it("Should get all users after deposits", async function () {
  //     const depositAmount = ethers.parseEther("1");

  //     await gameVault.connect(user1).deposit(await PLS_TOKEN, depositAmount, { value: depositAmount });
  //     await gameVault.connect(user2).deposit(await PLS_TOKEN, depositAmount, { value: depositAmount });

  //     const users = await gameVault.getAllUsers();
  //     expect(users).to.include(await user1.getAddress());
  //     expect(users).to.include(await user2.getAddress());
  //     expect(users.length).to.equal(2);
  //   });
  // });

  // describe("Emergency Functions", function () {
  //   beforeEach(async function () {
  //     // Send some ETH to contract
  //     await owner.sendTransaction({
  //       to: await gameVault.getAddress(),
  //       value: ethers.parseEther("1")
  //     });
  //   });

  //   it("Should rescue ETH", async function () {
  //     const rescueAmount = ethers.parseEther("0.5");
  //     const ownerBalanceBefore = await hre.ethers.provider.getBalance(await owner.getAddress());

  //     const tx = await gameVault.rescueEther(await owner.getAddress(), rescueAmount);



  //     const ownerBalanceAfter = await hre.ethers.provider.getBalance(await owner.getAddress());
  //     // expect(ownerBalanceAfter - ownerBalanceBefore + gasUsed).to.equal(rescueAmount);
  //   });

  //   it("Should revert rescue with zero addresses", async function () {
  //     await expect(
  //       gameVault.rescueEther("0x0000000000000000000000000000000000000000", ethers.parseEther("1"))
  //     ).to.be.revertedWithCustomError(gameVault, "ZeroAddress");
  //   });

  //   it("Should revert rescue with zero amount", async function () {
  //     await expect(
  //       gameVault.rescueEther(await owner.getAddress(), 0)
  //     ).to.be.revertedWithCustomError(gameVault, "InvalidAmount");
  //   });
  // });

  // describe("Withdrawal Access Control", function () {
  //   beforeEach(async function () {
  //     // Setup: deposit some ETH first
  //     const depositAmount = ethers.parseEther("1");
  //     await gameVault.connect(user1).deposit(await PLS_TOKEN, depositAmount, { value: depositAmount });
  //   });

  //   it("Should allow admin withdrawal", async function () {
  //     const withdrawAmount = ethers.parseEther("0.5");

  //     await expect(
  //       gameVault.connect(admin).adminWithdraw(await user1.getAddress(), await user1.getAddress(), PLS_TOKEN, withdrawAmount)
  //     ).to.emit(gameVault, "Withdrawn");
  //   });

  //   it("Should revert when non-admin tries to withdraw", async function () {
  //     await expect(
  //       gameVault.connect(user1).adminWithdraw(await user1.getAddress(), await user2.getAddress(), PLS_TOKEN, ethers.parseEther("0.1"))
  //     ).to.be.reverted;
  //   });
  // });
});