import { ethers, upgrades } from 'hardhat'
import { expect } from 'chai'
import { formatEther, parseEther } from 'ethers/lib/utils'
import { Contract } from 'ethers'
import { SignerWithAddress } from '@nomiclabs/hardhat-ethers/signers'
import colors from 'colors'

describe("VantablackDeployer Integration Tests - Advanced Scenarios", () => {
    let deployer: Contract
    let owner: SignerWithAddress
    let dev1: SignerWithAddress
    let dev2: SignerWithAddress
    let user1: SignerWithAddress
    let treasury: SignerWithAddress
    let mockRouter: Contract
    let mockToken: Contract
    let mockUnicryptLocker: Contract
    let mockWETH: Contract
    let mockFactory: Contract
    let mockPair: Contract

    const INITIAL_LP_FUNDING = parseEther("10")
    const LP_FUNDING_AMOUNT = parseEther("1.5")
    
    beforeEach(async () => {
        const signers = await ethers.getSigners()
        owner = signers[0]
        dev1 = signers[1]
        dev2 = signers[2]
        user1 = signers[3]
        treasury = signers[4]

        // Deploy all mock contracts
        const MockWETH = await ethers.getContractFactory("MockWETH")
        mockWETH = await MockWETH.deploy()

        const MockPair = await ethers.getContractFactory("MockPair")
        mockPair = await MockPair.deploy()

        const MockFactory = await ethers.getContractFactory("MockFactory")
        mockFactory = await MockFactory.deploy()
        await mockFactory.setPair(mockPair.address)

        const MockRouter = await ethers.getContractFactory("MockRouter")
        mockRouter = await MockRouter.deploy()
        await mockRouter.setFactory(mockFactory.address)
        await mockRouter.setWETH(mockWETH.address)

        const MockERC20 = await ethers.getContractFactory("MockERC20")
        mockToken = await MockERC20.deploy("MockToken", "MTK", parseEther("1000000"))

        const MockUnicryptLocker = await ethers.getContractFactory("MockUnicryptLocker")
        mockUnicryptLocker = await MockUnicryptLocker.deploy()

        // Deploy VantablackDeployer
        const VantablackDeployer = await ethers.getContractFactory("VantablackDeployer")
        deployer = await upgrades.deployProxy(VantablackDeployer, [], {
            initializer: 'initialize',
        })

        // Setup
        await deployer.setUnicryptLocker(mockUnicryptLocker.address)
        await deployer.fundLiquidityPool({ value: INITIAL_LP_FUNDING })
        await deployer.addToWhitelist(dev1.address)
        await deployer.addToWhitelist(dev2.address)
    })

    describe("Token Deployment Scenarios", () => {
        it("Should handle deployment with different LP management options", async () => {
            const testCases = [
                { option: 0, name: "Burn LP" },
                { option: 1, name: "Lock 1 Month" },  
                { option: 2, name: "Lock 6 Months" },
            ]

            for (const testCase of testCases) {
                const amounts = [parseEther("0.1"), 3600, testCase.option]
                const addrs = [dev1.address, treasury.address]
                const percents = [300, 500, 100, 200]
                const flags = [true, false, false]
                const metadata = [`Test${testCase.option}`, `T${testCase.option}`]

                console.log(colors.yellow(`Testing ${testCase.name} (option ${testCase.option})`))

                // This will test parameter validation
                const result = await deployer.connect(dev1).callStatic.deployToken(
                    amounts, addrs, percents, flags, metadata, { value: parseEther("1") }
                )
                expect(result).to.be.gt(0)
            }

            console.log(colors.green("✓ All LP management options validated"))
        })

        it("Should handle deployment with different fee structures", async () => {
            const feeTestCases = [
                { buy: 0, sell: 0, transfer: 0, burn: 0, name: "No Fees" },
                { buy: 100, sell: 200, transfer: 50, burn: 100, name: "Low Fees" },
                { buy: 300, sell: 500, transfer: 100, burn: 200, name: "Medium Fees" },
                { buy: 500, sell: 500, transfer: 500, burn: 500, name: "Maximum Fees" }
            ]

            for (const fees of feeTestCases) {
                const amounts = [parseEther("0.1"), 3600, 0]
                const addrs = [dev1.address, treasury.address]
                const percents = [fees.buy, fees.sell, fees.transfer, fees.burn]
                const flags = [true, false, false]
                const metadata = ["TestFees", "TF"]

                console.log(colors.yellow(`Testing ${fees.name}`))

                const result = await deployer.connect(dev1).callStatic.deployToken(
                    amounts, addrs, percents, flags, metadata, { value: parseEther("1") }
                )
                expect(result).to.be.gt(0)
            }

            console.log(colors.green("✓ All fee structures validated"))
        })

        it("Should reject invalid fee combinations", async () => {
            const invalidFeeTestCases = [
                { buy: 600, sell: 500, transfer: 100, burn: 200, error: "FeeTooHigh" },
                { buy: 300, sell: 600, transfer: 100, burn: 200, error: "FeeTooHigh" },
                { buy: 300, sell: 500, transfer: 600, burn: 200, error: "FeeTooHigh" }
            ]

            for (const fees of invalidFeeTestCases) {
                const amounts = [parseEther("0.1"), 3600, 0]
                const addrs = [dev1.address, treasury.address]
                const percents = [fees.buy, fees.sell, fees.transfer, fees.burn]
                const flags = [true, false, false]
                const metadata = ["TestInvalid", "TI"]

                await expect(
                    deployer.connect(dev1).deployToken(
                        amounts, addrs, percents, flags, metadata, { value: parseEther("1") }
                    )
                ).to.be.revertedWithCustomError(deployer, fees.error)
            }

            console.log(colors.green("✓ Invalid fee structures properly rejected"))
        })
    })

    describe("Whitelist Management Advanced", () => {
        it("Should handle batch whitelist operations", async () => {
            const newDevs = [user1.address, treasury.address]
            
            // Add multiple devs
            await deployer.addMultipleToWhitelist(newDevs)
            
            for (const dev of newDevs) {
                expect(await deployer.isWhitelisted(dev)).to.be.true
            }

            // Remove them individually
            for (const dev of newDevs) {
                await deployer.removeFromWhitelist(dev)
                expect(await deployer.isWhitelisted(dev)).to.be.false
            }

            console.log(colors.green("✓ Batch whitelist operations working"))
        })

        it("Should prevent deployment by removed developers", async () => {
            // Remove dev1 from whitelist
            await deployer.removeFromWhitelist(dev1.address)
            expect(await deployer.isWhitelisted(dev1.address)).to.be.false

            const amounts = [parseEther("0.1"), 3600, 0]
            const addrs = [dev1.address, treasury.address]
            const percents = [300, 500, 100, 200]
            const flags = [true, false, false]
            const metadata = ["TestRemoved", "TR"]

            await expect(
                deployer.connect(dev1).deployToken(
                    amounts, addrs, percents, flags, metadata, { value: parseEther("1") }
                )
            ).to.be.revertedWithCustomError(deployer, "NotWhitelisted")

            console.log(colors.green("✓ Removed developers cannot deploy"))
        })
    })

    describe("LP Funding Scenarios", () => {
        it("Should handle different funding levels", async () => {
            // Test with insufficient funding
            await deployer.withdrawEth(await ethers.provider.getBalance(deployer.address))
            
            let fundingBalance = await deployer.lpFundingBalance()
            expect(fundingBalance).to.equal(0)

            // Test with partial funding
            await deployer.fundLiquidityPool({ value: parseEther("0.5") })
            fundingBalance = await deployer.lpFundingBalance()
            expect(fundingBalance).to.equal(parseEther("0.5"))

            // Test with full funding
            await deployer.fundLiquidityPool({ value: parseEther("1") })
            fundingBalance = await deployer.lpFundingBalance()
            expect(fundingBalance).to.equal(parseEther("1.5"))

            console.log(colors.green("✓ Different funding levels handled"))
        })

        it("Should adjust funding requirements", async () => {
            // Change funding amount
            await deployer.setLpFundingAmount(parseEther("3"))
            expect(await deployer.lpFundingAmount()).to.equal(parseEther("3"))

            // Test that more funding is now required
            const currentBalance = await deployer.lpFundingBalance()
            console.log(colors.yellow(`Current balance: ${formatEther(currentBalance)} ETH`))
            console.log(colors.yellow(`Required amount: 3 ETH`))

            console.log(colors.green("✓ Funding requirements adjustable"))
        })
    })

    describe("Estimation Functions Advanced", () => {
        it("Should provide accurate estimations across different scenarios", async () => {
            const testScenarios = [
                {
                    name: "Small Buy",
                    ethAmount: parseEther("0.01"),
                    ethLP: parseEther("1"),
                    tokenLP: parseEther("1000000"),
                    buyTax: 100,
                    totalSupply: parseEther("1000000000")
                },
                {
                    name: "Medium Buy", 
                    ethAmount: parseEther("0.1"),
                    ethLP: parseEther("5"),
                    tokenLP: parseEther("5000000"),
                    buyTax: 300,
                    totalSupply: parseEther("1000000000")
                },
                {
                    name: "Large Buy",
                    ethAmount: parseEther("1"),
                    ethLP: parseEther("10"),
                    tokenLP: parseEther("10000000"),
                    buyTax: 500,
                    totalSupply: parseEther("1000000000")
                }
            ]

            for (const scenario of testScenarios) {
                console.log(colors.yellow(`Testing ${scenario.name}`))

                const estimation = await deployer.getFirstBuyEstimation(
                    scenario.ethAmount,
                    scenario.totalSupply,
                    scenario.ethLP,
                    scenario.tokenLP,
                    scenario.buyTax
                )

                expect(estimation.tokensReceived).to.be.gt(0)
                expect(estimation.taxPaid).to.equal(
                    scenario.ethAmount.mul(scenario.buyTax).div(10000)
                )
                expect(estimation.pricePerToken).to.be.gt(0)
                expect(estimation.marketCapAfter).to.be.gt(0)

                console.log(colors.cyan(`  Tokens: ${formatEther(estimation.tokensReceived)}`))
                console.log(colors.cyan(`  Tax: ${formatEther(estimation.taxPaid)} ETH`))
                console.log(colors.cyan(`  Price: ${estimation.pricePerToken} wei per token`))
                console.log(colors.cyan(`  Market Cap: ${formatEther(estimation.marketCapAfter)} ETH`))
            }

            console.log(colors.green("✓ Estimation functions accurate across scenarios"))
        })

        it("Should handle edge cases in estimations", async () => {
            // Test with zero tax
            let estimation = await deployer.getFirstBuyEstimation(
                parseEther("1"),
                parseEther("1000000000"),
                parseEther("10"),
                parseEther("10000000"),
                0 // No tax
            )

            expect(estimation.taxPaid).to.equal(0)
            expect(estimation.tokensReceived).to.be.gt(0)

            // Test with maximum tax
            estimation = await deployer.getFirstBuyEstimation(
                parseEther("1"),
                parseEther("1000000000"),
                parseEther("10"),
                parseEther("10000000"),
                500 // 5% tax
            )

            expect(estimation.taxPaid).to.equal(parseEther("0.05"))
            expect(estimation.tokensReceived).to.be.gt(0)

            console.log(colors.green("✓ Estimation edge cases handled"))
        })
    })

    describe("Error Handling Comprehensive", () => {
        it("Should handle all custom errors appropriately", async () => {
            const errorTests = [
                {
                    name: "InvalidAmount - Zero LP funding",
                    test: () => deployer.setLpFundingAmount(0),
                    error: "InvalidAmount"
                },
                {
                    name: "NonVantablackToken - Invalid token",
                    test: () => deployer.getProjectTaxBalance(user1.address),
                    error: "NonVantablackToken"
                },
                {
                    name: "ZeroAddress - Invalid owner",
                    test: () => {
                        const amounts = [parseEther("0.1"), 3600, 0]
                        const addrs = [ethers.constants.AddressZero, treasury.address]
                        const percents = [300, 500, 100, 200]
                        const flags = [true, false, false]
                        const metadata = ["Test", "T"]
                        return deployer.connect(dev1).deployToken(
                            amounts, addrs, percents, flags, metadata, { value: parseEther("1") }
                        )
                    },
                    error: "ZeroAddress"
                }
            ]

            for (const errorTest of errorTests) {
                console.log(colors.yellow(`Testing ${errorTest.name}`))
                await expect(errorTest.test()).to.be.revertedWithCustomError(
                    deployer, errorTest.error
                )
            }

            console.log(colors.green("✓ All custom errors handled properly"))
        })
    })

    describe("Gas Optimization Validation", () => {
        it("Should use gas-efficient patterns", async () => {
            // Test that functions use custom errors (more gas efficient)
            const errorFunctions = [
                { name: "setLpFundingAmount", args: [0], error: "InvalidAmount" },
                { name: "getProjectTaxBalance", args: [user1.address], error: "NonVantablackToken" }
            ]

            for (const func of errorFunctions) {
                await expect(
                    deployer[func.name](...func.args)
                ).to.be.revertedWithCustomError(deployer, func.error)
            }

            // Test that constants are properly set (gas efficient storage)
            expect(await deployer.MAX_FEE()).to.equal(500)
            expect(await deployer.LOCK_1_MONTH()).to.equal(30 * 24 * 3600)
            expect(await deployer.LOCK_6_MONTHS()).to.equal(180 * 24 * 3600)
            expect(await deployer.DEAD_ADDRESS()).to.equal(
                "0x000000000000000000000000000000000000dEaD"
            )

            console.log(colors.green("✓ Gas optimization patterns validated"))
        })
    })

    describe("Upgrade Testing", () => {
        it("Should maintain state after upgrades", async () => {
            // Record initial state
            const initialOwner = await deployer.owner()
            const initialFundingAmount = await deployer.lpFundingAmount()
            const initialTokenCount = await deployer.deployedTokensCount()

            // Test upgrade (this would normally deploy a new implementation)
            // For this test, we just verify the proxy pattern is working
            expect(initialOwner).to.equal(owner.address)
            expect(initialFundingAmount).to.equal(parseEther("3")) // From previous test
            expect(initialTokenCount).to.equal(0)

            console.log(colors.green("✓ Upgradeable proxy pattern working"))
        })
    })

    describe("Event Emission Comprehensive", () => {
        it("Should emit all expected events", async () => {
            // Test DevWhitelisted event
            await expect(deployer.addToWhitelist(user1.address))
                .to.emit(deployer, "DevWhitelisted")
                .withArgs(user1.address)

            // Test DevRemovedFromWhitelist event
            await expect(deployer.removeFromWhitelist(user1.address))
                .to.emit(deployer, "DevRemovedFromWhitelist")
                .withArgs(user1.address)

            console.log(colors.green("✓ All events properly emitted"))
        })
    })

    describe("Integration with External Contracts", () => {
        it("Should interact properly with Unicrypt Locker", async () => {
            // Test that Unicrypt integration is set up
            expect(await deployer.unicryptLocker()).to.equal(mockUnicryptLocker.address)

            // Test getting fees from Unicrypt
            const fees = await mockUnicryptLocker.gFees()
            expect(fees[0]).to.be.gt(0) // ethFee should be positive

            console.log(colors.green("✓ Unicrypt integration working"))
        })

        it("Should handle router interactions", async () => {
            // Since we're using mocks, we can test the integration points
            expect(await mockRouter.WETH()).to.not.equal(ethers.constants.AddressZero)
            expect(await mockRouter.factory()).to.equal(mockFactory.address)

            console.log(colors.green("✓ Router integration working"))
        })
    })

    it("Final Integration Test Summary", async () => {
        console.log(colors.magenta("\n=== INTEGRATION TEST SUMMARY ==="))
        console.log(colors.green("✓ Token deployment scenarios"))
        console.log(colors.green("✓ Advanced whitelist management"))
        console.log(colors.green("✓ LP funding scenarios"))
        console.log(colors.green("✓ Comprehensive estimation testing"))
        console.log(colors.green("✓ Error handling validation"))
        console.log(colors.green("✓ Gas optimization verification"))
        console.log(colors.green("✓ Upgrade compatibility"))
        console.log(colors.green("✓ Event emission testing"))
        console.log(colors.green("✓ External contract integration"))
        console.log(colors.magenta("============================\n"))
    })
})